# 桌面鬧鐘 Widget v1.1.0

Android 8 以上適用，針對 Samsung Galaxy S24 Ultra 設計。

## 功能

- 桌面即時顯示時間與日期
- 自動定位並顯示目前溫度／天氣圖示（Open-Meteo，免 API key）
- App 內新增一個鬧鐘，桌面顯示下一個鬧鐘
- 手機重新開機後自動恢復尚未到時的鬧鐘
- Widget 可自由調整大小
- Widget 完全透明、沒有底色及邊框
- App 內可拖曳時間、日期、天氣和鬧鐘，自訂大小、顏色、字型及顯示狀態
- 可選擇 MP4 作為鬧鐘影片；到時全螢幕循環播放

## 安裝後設定

1. 開啟 App，允許通知、精確鬧鐘和定位。
2. 選擇 MP4，設定時間與名稱，按「儲存鬧鐘」。
3. 長按手機桌面空白處 →「小工具」→「桌面鬧鐘」。

## GitHub 產出 APK

將 `DesktopAlarmWidget` 資料夾內容上傳到 GitHub repository 根目錄，開啟 Actions，執行 **Build Android APK**。完成後在 Artifacts 下載 APK。

> v1.1.0 一次管理一個鬧鐘；若 MP4 無法讀取，會自動改用系統預設鬧鐘聲。
