package com.kitty.desktopalarm;

import android.app.*; import android.media.*; import android.net.Uri; import android.os.*; import android.view.WindowManager; import android.widget.*;

public class AlarmRingActivity extends Activity {
    private VideoView video; private MediaPlayer fallback;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON); setContentView(R.layout.activity_alarm_ring); video=findViewById(R.id.alarmVideo); String label=getIntent().getStringExtra("label"); ((TextView)findViewById(R.id.ringTitle)).setText(label==null||label.isEmpty()?"鬧鐘時間到了":label); findViewById(R.id.stopAlarm).setOnClickListener(v->stopAndClose()); play(); }
    private void play(){ String raw=getSharedPreferences("alarm",0).getString("video",""); if(!raw.isEmpty()){ try{ video.setVideoURI(Uri.parse(raw)); video.setOnPreparedListener(m->{m.setLooping(true);m.setVolume(1f,1f);video.start();}); video.setOnErrorListener((m,w,e)->{fallback();return true;}); return; }catch(Exception ignored){} } fallback(); }
    private void fallback(){ try{ fallback=MediaPlayer.create(this,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)); fallback.setLooping(true); fallback.start(); }catch(Exception ignored){} }
    private void stopAndClose(){ if(video!=null)video.stopPlayback(); if(fallback!=null){fallback.stop();fallback.release();fallback=null;} ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(100); finishAndRemoveTask(); }
    @Override protected void onDestroy(){ if(video!=null)video.stopPlayback(); if(fallback!=null){fallback.release();fallback=null;} super.onDestroy(); }
}
