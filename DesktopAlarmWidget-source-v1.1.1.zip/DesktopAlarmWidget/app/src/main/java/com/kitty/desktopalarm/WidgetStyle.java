package com.kitty.desktopalarm;

import android.content.*;

public final class WidgetStyle {
 static final String[] N={"time","date","weather","alarm"};
 static final int[] DEFAULT_X={12,14,14,155}, DEFAULT_Y={8,70,105,105}, DEFAULT_SIZE={38,15,15,15};
 private static android.content.SharedPreferences p(Context c){return c.getSharedPreferences("widget_style",0);}
 static int x(Context c,int i){return p(c).getInt(N[i]+"X",DEFAULT_X[i]);} static int y(Context c,int i){return p(c).getInt(N[i]+"Y",DEFAULT_Y[i]);}
 static int size(Context c,int i){return p(c).getInt(N[i]+"Size",DEFAULT_SIZE[i]);} static int color(Context c,int i){return p(c).getInt(N[i]+"Color",i==1?0xff66558f:0xff493f58);}
 static boolean show(Context c,int i){return p(c).getBoolean(N[i]+"Show",true);} static int font(Context c){return p(c).getInt("font",0);}
 static void save(Context c,int i,int x,int y,int size,int color,boolean show){p(c).edit().putInt(N[i]+"X",x).putInt(N[i]+"Y",y).putInt(N[i]+"Size",size).putInt(N[i]+"Color",color).putBoolean(N[i]+"Show",show).apply();}
 static void font(Context c,int f){p(c).edit().putInt("font",f).apply();} static void reset(Context c){p(c).edit().clear().apply();}
}
