package com.kitty.desktopalarm;

import android.app.*; import android.content.*; import android.media.RingtoneManager; import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){ String channel="alarm"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel(channel,"鬧鐘",NotificationManager.IMPORTANCE_HIGH); ch.enableVibration(true); nm.createNotificationChannel(ch); } String label=AlarmStore.getLabel(c); Intent ring=new Intent(c,AlarmRingActivity.class).putExtra("label",label).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); PendingIntent pi=PendingIntent.getActivity(c,2,ring,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Notification n=new Notification.Builder(c,channel).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(label.isEmpty()?"鬧鐘時間到了":label).setContentText("點一下播放鬧鐘影片").setContentIntent(pi).setFullScreenIntent(pi,true).setCategory(Notification.CATEGORY_ALARM).setOngoing(true).build(); nm.notify(100,n); try{ c.startActivity(ring); }catch(Exception ignored){} AlarmStore.clear(c); ClockWidget.updateAll(c); }
}
