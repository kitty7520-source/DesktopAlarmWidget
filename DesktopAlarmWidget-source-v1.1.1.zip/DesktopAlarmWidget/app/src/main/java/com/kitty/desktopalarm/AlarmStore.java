package com.kitty.desktopalarm;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.*;

public final class AlarmStore {
    private static final String P="alarm", T="time", L="label";
    static long getTime(Context c){ return c.getSharedPreferences(P,0).getLong(T,0); }
    static String getLabel(Context c){ return c.getSharedPreferences(P,0).getString(L,""); }
    static void save(Context c,long time,String label){ c.getSharedPreferences(P,0).edit().putLong(T,time).putString(L,label).apply(); }
    static void clear(Context c){ c.getSharedPreferences(P,0).edit().remove(T).remove(L).apply(); }
    static String display(Context c){ long t=getTime(c); return t==0?"尚未設定":new SimpleDateFormat("M/d (E) HH:mm",Locale.TAIWAN).format(new Date(t)); }
}
