package com.kitty.desktopalarm;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_MP4=20;
    private TimePicker picker; private EditText label; private TextView next,mp4Status;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        picker=findViewById(R.id.timePicker); picker.setIs24HourView(true); label=findViewById(R.id.label); next=findViewById(R.id.nextAlarm); mp4Status=findViewById(R.id.mp4Status);
        ((TextView)findViewById(R.id.now)).setText(new SimpleDateFormat("yyyy年M月d日 EEEE",Locale.TAIWAN).format(new Date())); refresh();
        findViewById(R.id.saveAlarm).setOnClickListener(v->save());
        findViewById(R.id.designWidget).setOnClickListener(v->startActivity(new Intent(this,DesignActivity.class)));
        findViewById(R.id.selectMp4).setOnClickListener(v->{ Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("video/mp4"); startActivityForResult(pick,PICK_MP4); });
        findViewById(R.id.deleteAlarm).setOnClickListener(v->{ cancel(); AlarmStore.clear(this); ClockWidget.updateAll(this); refresh(); });
        findViewById(R.id.weather).setOnClickListener(v->requestWeather()); requestNotifications();
    }
    private void requestNotifications(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9); }
    private void requestWeather(){ if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},8); else WeatherUpdater.update(this); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==8&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED) WeatherUpdater.update(this); }
    private void save(){ Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,picker.getHour()); c.set(Calendar.MINUTE,picker.getMinute()); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0); if(c.getTimeInMillis()<=System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); Toast.makeText(this,"請允許精確鬧鐘後再按一次儲存",Toast.LENGTH_LONG).show(); return; }
        AlarmStore.save(this,c.getTimeInMillis(),label.getText().toString().trim()); schedule(c.getTimeInMillis()); ClockWidget.updateAll(this); refresh(); Toast.makeText(this,"鬧鐘已設定",Toast.LENGTH_SHORT).show(); }
    private PendingIntent alarmPi(){ return PendingIntent.getBroadcast(this,100,new Intent(this,AlarmReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); }
    private void schedule(long t){ ((AlarmManager)getSystemService(ALARM_SERVICE)).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,alarmPi()); }
    private void cancel(){ ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(alarmPi()); }
    @Override protected void onActivityResult(int request,int result,Intent data){ super.onActivityResult(request,result,data); if(request==PICK_MP4&&result==RESULT_OK&&data!=null){ Uri uri=data.getData(); if(uri!=null){ getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); getSharedPreferences("alarm",0).edit().putString("video",uri.toString()).apply(); refresh(); } } }
    private void refresh(){ next.setText("下一個鬧鐘："+AlarmStore.display(this)+(AlarmStore.getLabel(this).isEmpty()?"":"\n"+AlarmStore.getLabel(this))); String u=getSharedPreferences("alarm",0).getString("video",""); mp4Status.setText(u.isEmpty()?"尚未選擇 MP4":"已選擇 MP4 鬧鐘影片"); }
}
