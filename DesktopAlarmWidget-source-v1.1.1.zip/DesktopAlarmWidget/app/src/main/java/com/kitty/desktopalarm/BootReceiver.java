package com.kitty.desktopalarm;

import android.app.*; import android.content.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ long t=AlarmStore.getTime(c); if(t>System.currentTimeMillis()){ PendingIntent p=PendingIntent.getBroadcast(c,100,new Intent(c,AlarmReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p); } ClockWidget.updateAll(c); } }
