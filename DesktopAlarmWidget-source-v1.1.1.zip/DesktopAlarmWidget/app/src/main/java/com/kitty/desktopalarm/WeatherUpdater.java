package com.kitty.desktopalarm;

import android.annotation.SuppressLint; import android.content.*; import android.location.*; import java.io.*; import java.net.*; import org.json.JSONObject;

public final class WeatherUpdater {
    @SuppressLint("MissingPermission") static void update(Context c){ LocationManager lm=(LocationManager)c.getSystemService(Context.LOCATION_SERVICE); try { lm.getCurrentLocation(LocationManager.GPS_PROVIDER,null,c.getMainExecutor(),loc->{ if(loc!=null) fetch(c,loc); }); } catch(SecurityException ignored){} }
    private static void fetch(Context c,Location l){ new Thread(()->{ try { String u="https://api.open-meteo.com/v1/forecast?latitude="+l.getLatitude()+"&longitude="+l.getLongitude()+"&current=temperature_2m,weather_code&timezone=auto"; HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection(); h.setConnectTimeout(10000); h.setReadTimeout(10000); JSONObject cur=new JSONObject(read(h.getInputStream())).getJSONObject("current"); double temp=cur.getDouble("temperature_2m"); int code=cur.getInt("weather_code"); String text=icon(code)+" "+Math.round(temp)+"°C"; c.getSharedPreferences("weather",0).edit().putString("text",text).apply(); ClockWidget.updateAll(c); }catch(Exception ignored){} }).start(); }
    private static String read(InputStream in)throws IOException{ BufferedReader r=new BufferedReader(new InputStreamReader(in)); StringBuilder b=new StringBuilder(); String s; while((s=r.readLine())!=null)b.append(s); return b.toString(); }
    private static String icon(int c){ if(c==0)return "☀"; if(c<=3)return "⛅"; if(c<=48)return "🌫"; if(c<=67)return "🌧"; if(c<=77)return "🌨"; if(c<=82)return "🌦"; return "⛈"; }
}
