package com.kitty.desktopalarm;

import android.app.*; import android.appwidget.*; import android.content.*; import android.util.TypedValue; import android.view.View; import android.widget.RemoteViews;

public class ClockWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){ for(int id:ids) update(c,m,id); WeatherUpdater.update(c); }
    static void updateAll(Context c){ AppWidgetManager m=AppWidgetManager.getInstance(c); int[] ids=m.getAppWidgetIds(new ComponentName(c,ClockWidget.class)); for(int id:ids) update(c,m,id); }
    static void update(Context c,AppWidgetManager m,int id){ int f=WidgetStyle.font(c); int layout=f==1?R.layout.widget_clock_serif:f==2?R.layout.widget_clock_mono:R.layout.widget_clock; RemoteViews v=new RemoteViews(c.getPackageName(),layout); String weather=c.getSharedPreferences("weather",0).getString("text","☁ 點一下更新天氣"); v.setTextViewText(R.id.widgetWeather,weather); v.setTextViewText(R.id.widgetAlarm,"⏰ "+AlarmStore.display(c)); int[] views={R.id.widgetTime,R.id.widgetDate,R.id.widgetWeather,R.id.widgetAlarm}; float d=c.getResources().getDisplayMetrics().density; for(int i=0;i<4;i++){v.setViewPadding(views[i],Math.round(WidgetStyle.x(c,i)*d),Math.round(WidgetStyle.y(c,i)*d),0,0);v.setTextViewTextSize(views[i],TypedValue.COMPLEX_UNIT_SP,WidgetStyle.size(c,i));v.setTextColor(views[i],WidgetStyle.color(c,i));v.setViewVisibility(views[i],WidgetStyle.show(c,i)?View.VISIBLE:View.GONE);} Intent open=new Intent(c,MainActivity.class); v.setOnClickPendingIntent(R.id.widgetRoot,PendingIntent.getActivity(c,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)); m.updateAppWidget(id,v); }
}
